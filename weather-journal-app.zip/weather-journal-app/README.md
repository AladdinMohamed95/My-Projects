# Weather-Journal App Project

## Project Title : Weather Journal

## Instructions

Weather Journal is my second project,I hope you enjoy what i have made with my hands according to what i have learned so far.

I have created an asynchronous web app that uses Web API and user data to dynamically update the UI.

I have modified server.js file and the website/app.js file.
and i have modified index.html and style.css files after i finished with the project steps.

I have install the express,body-parse and cors packages with command
node install in the terminal in my project folder and i wrote the basic contents in the server.js file such as require express,body-parser and cors and the port that server listens to.

I have created a get & post routes to get and post data with app.js file.

In app.js file:

1. I created a promise async function which awaits fetching the api url and convert it into json.

2. I have created addEventListener on generate button to perform actions such as:

- data object contains data from user city and feelings and passing to it the data fetched from the api link like country,temprature and date.

- if users enters wrong city name it catchs the error and show a label with "City Not Found" message.

3. Posting the data to the server.js file with post route method.

4. I have created a async function to update ui elements with the data fetched.

Finally i hope you enjoy!
Thanks for your Time.

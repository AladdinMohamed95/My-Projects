const apiKey = "290a62f1951ff39c64405d790aa70846";
let d = new Date();
let newDate = d.getDate() + "." + d.getMonth() + 1 + "." + d.getFullYear();
//---------------------------------------get api data---------------------------------------
async function apiData(cityName) {
  return await (
    await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}&units=metric`
    )
  ).json();
}
//---------------------------------------generate button---------------------------------------
//passing api data to data object and when user enters awrong city it gives error City Not Found
const generateBtn = document.getElementById("generate");
generateBtn.addEventListener("click", performAction);
function performAction() {
  document.getElementById("notFound").textContent = "";
  data = {
    cityName: document.getElementById("zip").value,
    country: "",
    date: newDate,
    temp: "",
    description: "",
    content: document.getElementById("feelings").value,
  };
  apiData(data.cityName)
    .then((apiData) => {
      data.country = apiData.sys.country;
      data.temp = Math.round(apiData.main.temp);
      data.description = apiData.weather[0].description;
      postData(data);
    })
    .catch((err) => {
      console.log("notFound", err);
      document.getElementById("notFound").textContent = "City Not Found!";
    });
}
//---------------------------------------post data---------------------------------------
//post data function
const postData = async (url = "http://localhost:8000/postData") => {
  console.log(data);
  const response = await fetch("http://localhost:8000/postData", {
    method: "post",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  try {
    response.json().then(updateUI());
  } catch {
    (err) => {
      console.log("Error", err);
    };
  }
};
//---------------------------------------update ui---------------------------------------
//update ui function
const updateUI = async () => {
  const response = await fetch(`http://localhost:8000/all`);
  try {
    response
      .json()
      .then((data) => {
        document.getElementById(
          "country"
        ).innerHTML = `Country: ${data.country}`;
        document.getElementById("date").innerHTML = `Date: ${data.date}`;
        document.getElementById("temp").innerHTML = `Temp: ${data.temp}`;
        document.getElementById(
          "description"
        ).innerHTML = `Weather: ${data.description}`;
        document.getElementById(
          "content"
        ).innerHTML = `My Feeling: ${data.content}`;
      })
      .catch((err) => {
        console.log("Error", err);
      });
  } catch (err) {
    console.log("Error", err);
  }
};

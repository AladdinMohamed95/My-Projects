/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */
//---------------------------buttons----------------------------
// Add Button to Create A 5 new scetions only
let addBtn = document.createElement("button");
addBtn.classList.add("myBtnClass");
//button text
addBtn.textContent = "Add 5 Sections";
//select h1 element to append button
let landingHeader = document.querySelector("h1");
landingHeader.appendChild(addBtn);
//---------------------------------------------------
// Add Button to back to the top
let topBtn = document.createElement("button");
//button text
topBtn.textContent = "Top";

let pageFooter = document.querySelector(".page__footer");
pageFooter.appendChild(topBtn);

const showOnPx = 100;
const scrollContainer = () => {
  return document.documentElement || document.body;
};
//event back to the top
document.addEventListener("scroll", () => {
  if (scrollContainer().scrollTop > showOnPx) {
    topBtn.classList.remove("hidden");
  } else {
    topBtn.classList.add("hidden");
  }
});
const goToTop = () => {
  document.body.scrollTo({ top: 0, behavior: "smooth" });
};
topBtn.addEventListener("click", goToTop);

window.onload = () => {
  topBtn.style = "opacity:0";
};
//*-------------------------------------------------------------
//-------------------------Add Sections-------------------------
//function creates 5 sections using for loop
addBtn.onclick = () => {
  for (i = 1; i <= 5; i++) {
    //create section element
    let mySection = document.createElement("section");
    //setting attributes to section
    mySection.setAttribute("id", `section${i}`);
    mySection.setAttribute("data-nav", `section${i}`);
    //create div element
    let mySectionDiv = document.createElement("div");
    mySectionDiv.className = "landing__container";
    //append div to section
    mySection.appendChild(mySectionDiv);

    // Add Heading Text
    let myHeading = document.createElement("h2");
    let myHeadingText = document.createTextNode(`Section ${i}`);
    //append text to h2 element
    myHeading.appendChild(myHeadingText);

    //create first paragraph element
    let myParagraph1 = document.createElement("p");

    myParagraph1.textContent = `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi
            fermentum metus faucibus lectus pharetra dapibus. Suspendisse
            potenti. Aenean aliquam elementum mi, ac euismod augue. Donec eget
            lacinia ex. Phasellus imperdiet porta orci eget mollis. Sed
            convallis sollicitudin mauris ac tincidunt. Donec bibendum, nulla
            eget bibendum consectetur, sem nisi aliquam leo, ut pulvinar quam
            nunc eu augue. Pellentesque maximus imperdiet elit a pharetra. Duis
            lectus mi, aliquam in mi quis, aliquam porttitor lacus. Morbi a
            tincidunt felis. Sed leo nunc, pharetra et elementum non, faucibus
            vitae elit. Integer nec libero venenatis libero ultricies molestie
            semper in tellus. Sed congue et odio sed euismod.`;
    //create second paragraph element
    let myParagraph2 = document.createElement("p");
    myParagraph2.textContent = ` Aliquam a convallis justo. Vivamus venenatis, erat eget pulvinar
            gravida, ipsum lacus aliquet velit, vel luctus diam ipsum a diam.
            Cras eu tincidunt arcu, vitae rhoncus purus. Vestibulum fermentum
            consectetur porttitor. Suspendisse imperdiet porttitor tortor, eget
            elementum tortor mollis non.`;
    //append Heading & paragraph to div
    mySectionDiv.appendChild(myHeading);
    mySectionDiv.appendChild(myParagraph1);
    mySectionDiv.appendChild(myParagraph2);

    // Add myElement to Body
    let myMain = document.querySelector("main");
    myMain.appendChild(mySection);
  }
};
//create event listener to hide add sections button after clicked.
addBtn.addEventListener("click", () => {
  addBtn.style.cssText = "display:none";
  topBtn.style.cssText =
    'float:right;font-family: "Fira Sans", sans-serif;background-color: #cc1;font-size: 20px;font-weight: bold;color: #0f2248;border: 4px solid #fff;padding: 5px;border-radius: 100px;';
});
//---------------------------------------------
//bulid the menu
//create function to build navbar
addBtn.addEventListener("click", () => {
  for (x = 1; x < i; x++) {
    //create section element
    let navbarList = document.getElementById("navbar__list");
    navbarList.classList.add("myNavList");
    //create li element
    let ulList = document.createElement("li");
    ulList.setAttribute("id", `li ${x}`);
    ulList.setAttribute("data-nav", `section${x}`);
    ulList.textContent = `Section ${x}`;

    const el = document.createElement("a");
    el.classList.add("menu__link");
    el.setAttribute("id", `menu-${x}`);
    el.setAttribute("href", `#section ${x}`);
    ulList.appendChild(el);

    //append li to ul
    navbarList.appendChild(ulList);
  }
  //smooth scrolling to sections on mouse click
  for (z = 1; z <= 5; z++) {
    let ulList = document.getElementById(`li ${z}`);
    let sec = document.getElementById(`section${z}`);
    ulList.addEventListener("click", function () {
      sec.scrollIntoView({ behavior: "smooth" });
    });
  }
  //---- highlight sections & navbar on scrolling

  navbarList = document.getElementById("navbar__list");
  window.onscroll = function () {
    document.querySelectorAll("section").forEach(function (active) {
      let activeLink = navbarList.querySelector(`[data-nav=${active.id}]`);
      if (
        active.getBoundingClientRect().top >= -400 &&
        active.getBoundingClientRect().top <= 150
      ) {
        active.classList.add("your-active-class");
        activeLink.classList.add("link__active");
        active.style.cssText = "background: #390849;border-radius: 20px;";
        activeLink.style.cssText = "color: #cc1;";
      } else {
        active.classList.remove("your-active-class");
        activeLink.classList.remove("link__active");
        active.style.removeProperty("background");
        activeLink.style.removeProperty("color");
      }
    });
  };
});

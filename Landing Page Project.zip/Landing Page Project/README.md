# Landing Page Project

## Project Title : Landing Page Project

## Instructions

Manipulating the DOM is my first project,I hope you enjoy what i have made with my hands according to what i have learned so far.

All of the page elements was made using Javascript.

I have added a button to add five dynamic sections and disapear once the button clicked.

I have build the navbar which navigate to sections when a section clicked.

I have created a function to highlight sections and navbar on scrolling with your-active-class attribute.

i have created a button to scroll to top page in footer.

All features are usable across modern desktop, tablet, and phone browsers.
